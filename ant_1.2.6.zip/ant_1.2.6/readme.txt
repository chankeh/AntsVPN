﻿蚂蚁加速器，帮助你自由安全的畅游互联网。
本软件绝对安全，请放心使用。
本软件需要微软公司的 .NET Framework 4.7.2 运行环境支持，如果没有安装，请前往下载

.NET Framework 4.7.2 下载地址：https://dotnet.microsoft.com/download/thank-you/net472-offline
蚂蚁加速器官网地址：https://aff.antss019.com/

提示：如发现连接后无法正常使用，请将路径改为英文再尝试
如果你使用本软件觉得还满意，请推荐给你身边的朋友，谢谢支持

对 ant.exe 的签名特征如下：
7.71 MB (8085504 bytes) 

	MD5：7019dfce7ece9cf7f330a8016fbc6682
	SHA-1：51959179800c38b2363de636d75df53665711f4c
	SHA-256：e1a1c5ff46528336c8405d555ce3223d9a2ea127454ef4f8478f52d70545f329

